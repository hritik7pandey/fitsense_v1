'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { GlassInput, GlassButton } from '@/components/ui';
import { Mail, Lock, ChevronLeft, Sparkles, Dumbbell } from 'lucide-react';
import { motion } from 'framer-motion';
import { useAuth } from '@/lib/auth-context';

export default function LoginPage() {
  const router = useRouter();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email, password);
      // Small delay to ensure localStorage is written, then redirect
      setTimeout(() => {
        window.location.href = '/app/home';
      }, 100);
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check your credentials.');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex relative overflow-hidden bg-primary">
      {/* Animated Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent-blue/10 via-primary to-primary" />
        <motion.div 
          animate={{ scale: [1, 1.3, 1], opacity: [0.2, 0.4, 0.2] }}
          transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
          className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent-blue/20 rounded-full blur-[150px]" 
        />
        <motion.div 
          animate={{ scale: [1.2, 1, 1.2], opacity: [0.2, 0.3, 0.2] }}
          transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
          className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-accent-purple/20 rounded-full blur-[150px]" 
        />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:60px_60px]" />
      </div>

      {/* Left Side - Branding (Desktop) */}
      <div className="hidden lg:flex w-1/2 relative items-center justify-center p-12">
        <div className="relative z-10 max-w-lg">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-accent-blue to-accent-purple flex items-center justify-center">
                <Dumbbell size={28} className="text-white" />
              </div>
              <span className="text-3xl font-bold">FitSense</span>
            </div>
            
            <h1 className="text-5xl font-bold mb-6 leading-tight">
              Welcome back to your
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-blue to-accent-purple"> fitness journey</span>
            </h1>
            
            <p className="text-xl text-white/60 mb-10">
              Track your progress, crush your goals, and transform your life with AI-powered fitness.
            </p>

            <div className="flex flex-wrap gap-3">
              {['AI Workouts', 'Smart Nutrition', 'Progress Tracking'].map((feature, i) => (
                <motion.div
                  key={feature}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm text-white/70 flex items-center gap-2"
                >
                  <Sparkles size={14} className="text-accent-blue" />
                  {feature}
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>

      {/* Right Side - Form */}
      <div className="w-full lg:w-1/2 flex flex-col justify-center px-6 md:px-16 lg:px-20 relative z-10">
        <div className="max-w-md mx-auto w-full">
          <motion.button 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            onClick={() => router.push('/landing')} 
            className="absolute top-8 left-6 md:left-16 lg:left-20 w-10 h-10 flex items-center justify-center rounded-full bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all"
          >
            <ChevronLeft size={20} />
          </motion.button>

          {/* Mobile Logo */}
          <div className="lg:hidden flex items-center gap-3 mb-8 mt-16">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-accent-blue to-accent-purple flex items-center justify-center">
              <Dumbbell size={20} className="text-white" />
            </div>
            <span className="text-xl font-bold">FitSense</span>
          </div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="mb-8"
          >
            <h2 className="text-3xl md:text-4xl font-bold mb-3">Sign In</h2>
            <p className="text-white/50">Enter your credentials to continue</p>
          </motion.div>

          {error && (
            <motion.div 
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-6 p-4 rounded-xl bg-red-500/10 border border-red-500/20 text-red-400 text-sm"
            >
              {error}
            </motion.div>
          )}

          <motion.form 
            onSubmit={handleLogin}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <GlassInput 
              label="Email Address" 
              type="email" 
              icon={<Mail size={18} />}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <GlassInput 
              label="Password" 
              type="password" 
              icon={<Lock size={18} />}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />

            <div className="flex justify-between items-center mb-8">
              <label className="flex items-center gap-2 text-sm text-white/50 cursor-pointer group">
                <input type="checkbox" className="w-4 h-4 rounded bg-white/10 border-white/20 accent-accent-blue" />
                <span className="group-hover:text-white/70 transition-colors">Remember me</span>
              </label>
              <button 
                type="button" 
                onClick={() => router.push('/forgot-password')} 
                className="text-accent-blue text-sm hover:text-accent-glow transition-colors"
              >
                Forgot Password?
              </button>
            </div>

            <GlassButton type="submit" fullWidth size="lg" disabled={loading}>
              {loading ? (
                <span className="flex items-center gap-2">
                  <motion.div 
                    animate={{ rotate: 360 }}
                    transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                    className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                  />
                  Signing In...
                </span>
              ) : 'Sign In'}
            </GlassButton>
          </motion.form>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="mt-8 text-center"
          >
            <span className="text-sm text-white/40">Don&apos;t have an account? </span>
            <button 
              onClick={() => router.push('/register')} 
              className="text-accent-blue font-semibold hover:text-accent-glow transition-colors"
            >
              Create Account
            </button>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
