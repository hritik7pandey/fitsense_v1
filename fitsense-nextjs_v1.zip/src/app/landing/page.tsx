'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { WebsiteLayout } from '@/components/layouts/WebsiteLayout';
import { GlassButton } from '@/components/ui';
import { motion, useScroll, useTransform } from 'framer-motion';
import { CheckCircle, Zap, TrendingUp, Users, Award, ArrowRight, Star, Clock, Target, Sparkles, Play, Shield } from 'lucide-react';

export default function LandingPage() {
  const router = useRouter();
  const { scrollYProgress } = useScroll();
  const opacity = useTransform(scrollYProgress, [0, 0.15], [1, 0]);
  const scale = useTransform(scrollYProgress, [0, 0.15], [1, 0.95]);

  return (
    <WebsiteLayout>
      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-accent-blue/20 via-primary to-primary z-10" />
          <img 
            src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?q=80&w=2070&auto=format&fit=crop"
            alt="Gym"
            className="w-full h-full object-cover opacity-30"
          />
          <motion.div 
            animate={{ scale: [1, 1.3, 1], opacity: [0.3, 0.5, 0.3], x: [0, 50, 0] }}
            transition={{ duration: 12, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-accent-blue/30 rounded-full blur-[150px]" 
          />
          <motion.div 
            animate={{ scale: [1.2, 1, 1.2], opacity: [0.3, 0.5, 0.3], x: [0, -30, 0] }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
            className="absolute bottom-1/4 right-1/4 w-[600px] h-[600px] bg-accent-purple/25 rounded-full blur-[150px]" 
          />
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:80px_80px] z-10" />
        </div>

        <motion.div 
          style={{ opacity, scale }}
          className="relative z-20 max-w-6xl mx-auto text-center px-6 py-20"
        >
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="inline-flex items-center gap-2 px-5 py-2.5 rounded-full border border-accent-blue/40 bg-accent-blue/10 backdrop-blur-xl mb-8"
            >
              <Sparkles size={16} className="text-accent-blue" />
              <span className="text-accent-blue text-sm font-semibold">AI-Powered Fitness Platform</span>
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
            </motion.div>
            
            <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold mb-8 tracking-tight leading-[1.05]">
              Transform Your
              <br />
              <span className="relative">
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-blue via-accent-glow to-accent-purple">
                  Body & Mind
                </span>
                <motion.div 
                  className="absolute -bottom-2 left-0 right-0 h-1 bg-gradient-to-r from-accent-blue to-accent-purple rounded-full"
                  initial={{ scaleX: 0 }}
                  animate={{ scaleX: 1 }}
                  transition={{ delay: 1, duration: 0.8 }}
                />
              </span>
            </h1>
            
            <p className="text-lg md:text-xl text-white/70 mb-12 max-w-3xl mx-auto leading-relaxed">
              Experience the future of fitness with AI-powered workouts, personalized nutrition plans, 
              and real-time progress tracking. Your transformation journey starts here.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-16">
              <GlassButton 
                onClick={() => router.push('/register')} 
                size="lg" 
                className="w-full sm:w-auto min-w-[220px] group text-base"
              >
                Start Free Trial
                <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </GlassButton>
              <GlassButton 
                onClick={() => router.push('/login')} 
                variant="glass" 
                size="lg" 
                className="w-full sm:w-auto min-w-[220px] text-base"
              >
                <Play size={18} className="mr-2" />
                Watch Demo
              </GlassButton>
            </div>

            <div className="grid grid-cols-3 gap-6 md:gap-12 max-w-2xl mx-auto">
              {[
                { value: '10K+', label: 'Active Members' },
                { value: '50K+', label: 'Workouts Done' },
                { value: '4.9★', label: 'App Rating' }
              ].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.8 + i * 0.15 }}
                  className="text-center"
                >
                  <div className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-white to-white/80 bg-clip-text text-transparent mb-1">
                    {stat.value}
                  </div>
                  <div className="text-xs md:text-sm text-white/50">{stat.label}</div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
        >
          <motion.div
            animate={{ y: [0, 12, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
            className="w-6 h-10 border-2 border-white/20 rounded-full flex items-start justify-center p-2"
          >
            <motion.div className="w-1.5 h-2.5 bg-accent-blue rounded-full" />
          </motion.div>
        </motion.div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 px-6 relative">
        <div className="max-w-7xl mx-auto">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center mb-16"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-accent-blue/10 border border-accent-blue/20 text-accent-blue text-sm font-semibold mb-6">
              Features
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-5">Everything You Need</h2>
            <p className="text-white/60 text-lg max-w-2xl mx-auto">
              Cutting-edge technology meets proven fitness science for maximum results
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Zap, title: "AI Workouts", desc: "Personalized training plans that adapt to your progress in real-time.", color: "from-yellow-500 to-orange-500" },
              { icon: Target, title: "Smart Nutrition", desc: "Custom meal plans with precise macro tracking for your goals.", color: "from-green-500 to-emerald-500" },
              { icon: TrendingUp, title: "Progress Analytics", desc: "Visualize your journey with detailed charts and metrics.", color: "from-blue-500 to-cyan-500" },
              { icon: Users, title: "Expert Coaching", desc: "Get guidance from certified trainers whenever you need.", color: "from-purple-500 to-pink-500" },
              { icon: Clock, title: "24/7 Access", desc: "Train on your schedule with round-the-clock support.", color: "from-red-500 to-rose-500" },
              { icon: Award, title: "Achievements", desc: "Stay motivated with badges and community challenges.", color: "from-indigo-500 to-violet-500" }
            ].map((feature, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -8, transition: { duration: 0.2 } }}
                className="group p-8 rounded-2xl bg-gradient-to-br from-white/[0.08] to-transparent border border-white/[0.08] backdrop-blur-sm hover:bg-white/[0.12] hover:border-accent-blue/30 transition-all duration-300"
              >
                <div className={`w-14 h-14 bg-gradient-to-br ${feature.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                  <feature.icon size={26} className="text-white" />
                </div>
                <h3 className="text-xl font-bold mb-3 group-hover:text-accent-blue transition-colors">{feature.title}</h3>
                <p className="text-white/60 leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-24 px-6 bg-gradient-to-b from-transparent via-accent-blue/5 to-transparent">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-accent-purple/10 border border-accent-purple/20 text-accent-purple text-sm font-semibold mb-6">
              How It Works
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-5">Start in 3 Simple Steps</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Create Account', desc: 'Sign up in seconds and set your fitness goals' },
              { step: '02', title: 'Get Your Plan', desc: 'AI generates personalized workout & diet plans' },
              { step: '03', title: 'Start Training', desc: 'Follow your plan and track your progress' }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15 }}
                className="text-center relative"
              >
                <div className="text-6xl font-bold text-accent-blue/20 mb-4">{item.step}</div>
                <h3 className="text-xl font-bold mb-2">{item.title}</h3>
                <p className="text-white/60">{item.desc}</p>
                {i < 2 && (
                  <div className="hidden md:block absolute top-8 right-0 translate-x-1/2 w-16 h-0.5 bg-gradient-to-r from-accent-blue/50 to-transparent" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section id="testimonials" className="py-24 px-6 relative overflow-hidden">
        <div className="max-w-7xl mx-auto relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-semibold mb-6">
              Success Stories
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-5">Real Results, Real People</h2>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Rahul Sharma", role: "Lost 15kg in 4 months", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=200&auto=format&fit=crop", quote: "FitSense transformed my life. The AI workouts are incredibly effective!" },
              { name: "Priya Patel", role: "Gained muscle & confidence", image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=200&auto=format&fit=crop", quote: "The personalized nutrition plan was a game-changer for my fitness journey." },
              { name: "Arjun Kumar", role: "Marathon Runner", image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=200&auto=format&fit=crop", quote: "Progress tracking helped me improve my marathon time by 25 minutes!" }
            ].map((testimonial, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="p-8 rounded-2xl bg-gradient-to-br from-white/[0.08] to-transparent border border-white/[0.08] backdrop-blur-sm"
              >
                <div className="flex items-center gap-4 mb-6">
                  <img src={testimonial.image} alt={testimonial.name} className="w-14 h-14 rounded-full object-cover border-2 border-accent-blue/30" />
                  <div>
                    <div className="font-bold">{testimonial.name}</div>
                    <div className="text-sm text-accent-blue">{testimonial.role}</div>
                  </div>
                </div>
                <p className="text-white/70 leading-relaxed italic mb-4">&ldquo;{testimonial.quote}&rdquo;</p>
                <div className="flex gap-1">
                  {[...Array(5)].map((_, j) => (
                    <Star key={j} size={16} className="fill-yellow-500 text-yellow-500" />
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 px-6 relative">
        <div className="max-w-6xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <span className="inline-block px-4 py-1.5 rounded-full bg-accent-blue/10 border border-accent-blue/20 text-accent-blue text-sm font-semibold mb-6">
              Pricing
            </span>
            <h2 className="text-4xl md:text-5xl font-bold mb-5">Simple, Transparent Pricing</h2>
            <p className="text-white/60 text-lg">Choose the plan that fits your fitness goals</p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: "Basic", price: "999", period: "month", features: ["Gym Access", "Basic Workouts", "Progress Tracking", "Community Access"] },
              { name: "Pro", price: "1,999", period: "month", features: ["Everything in Basic", "AI Workouts", "Nutrition Plans", "Priority Support", "Video Tutorials"], popular: true },
              { name: "Elite", price: "3,999", period: "month", features: ["Everything in Pro", "Personal Trainer", "Custom Meal Prep", "24/7 Support", "1-on-1 Coaching"] }
            ].map((plan, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                whileHover={{ y: -8 }}
                className={`p-8 rounded-2xl border backdrop-blur-sm relative ${
                  plan.popular 
                    ? 'bg-gradient-to-b from-accent-blue/20 to-accent-purple/10 border-accent-blue/50 shadow-[0_0_60px_rgba(79,156,255,0.15)]' 
                    : 'bg-gradient-to-br from-white/[0.08] to-transparent border-white/[0.08]'
                }`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-gradient-to-r from-accent-blue to-accent-purple text-white text-xs font-bold rounded-full">
                    MOST POPULAR
                  </div>
                )}
                <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
                <div className="mb-6">
                  <span className="text-5xl font-bold">₹{plan.price}</span>
                  <span className="text-white/50">/{plan.period}</span>
                </div>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, j) => (
                    <li key={j} className="flex items-center gap-3 text-white/70">
                      <CheckCircle size={18} className="text-accent-blue flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <GlassButton onClick={() => router.push('/register')} fullWidth variant={plan.popular ? 'primary' : 'glass'}>
                  Get Started
                </GlassButton>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute inset-0 bg-gradient-to-t from-primary via-primary/95 to-primary/90" />
          <motion.div 
            animate={{ scale: [1, 1.2, 1], opacity: [0.2, 0.4, 0.2] }}
            transition={{ duration: 10, repeat: Infinity }}
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-accent-blue/20 rounded-full blur-[200px]" 
          />
        </div>
        
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center relative z-10"
        >
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-semibold mb-8">
            <Shield size={16} />
            7-Day Free Trial • No Credit Card Required
          </div>
          
          <h2 className="text-4xl md:text-6xl font-bold mb-6">
            Ready to Transform
            <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-accent-blue to-accent-purple">
              Your Life?
            </span>
          </h2>
          <p className="text-xl text-white/70 mb-10 max-w-2xl mx-auto">
            Join thousands of members crushing their fitness goals with FitSense.
          </p>
          <GlassButton 
            onClick={() => router.push('/register')} 
            size="lg"
            className="min-w-[280px] group text-base"
          >
            Start Your Free Trial
            <ArrowRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
          </GlassButton>
        </motion.div>
      </section>
    </WebsiteLayout>
  );
}
