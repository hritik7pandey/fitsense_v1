import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';

// GET /api/v1/admin/stats - Get admin dashboard stats
export async function GET(request: NextRequest) {
  const authResult = await authenticateRequest(request);
  if (authResult instanceof NextResponse) return authResult;

  const adminCheck = requireAdmin(authResult);
  if (adminCheck instanceof NextResponse) return adminCheck;

  try {
    // Total members
    const totalMembersResult = await query(`
      SELECT COUNT(*) as count FROM users WHERE role = 'MEMBER'
    `);
    const totalMembers = parseInt(totalMembersResult.rows[0]?.count || '0');

    // Active members (with active membership)
    const activeMembersResult = await query(`
      SELECT COUNT(DISTINCT m."userId") as count 
      FROM memberships m 
      WHERE m.status = 'ACTIVE' AND m."endDate" >= NOW()
    `);
    const activeMembers = parseInt(activeMembersResult.rows[0]?.count || '0');

    // Today's check-ins
    const todayCheckInsResult = await query(`
      SELECT COUNT(*) as count FROM attendance 
      WHERE DATE("createdAt") = CURRENT_DATE
    `);
    const todayCheckIns = parseInt(todayCheckInsResult.rows[0]?.count || '0');

    // Total revenue (sum of all membership payments)
    const revenueResult = await query(`
      SELECT COALESCE(SUM(p.price), 0) as total 
      FROM memberships m
      JOIN plans p ON m."planId" = p.id
    `);
    const totalRevenue = parseFloat(revenueResult.rows[0]?.total || '0');

    // Recent activity
    const recentActivityResult = await query(`
      SELECT 
        u.name,
        a."createdAt" as time,
        'check-in' as type
      FROM attendance a
      JOIN users u ON a."userId" = u.id
      ORDER BY a."createdAt" DESC
      LIMIT 5
    `);

    const recentActivity = recentActivityResult.rows.map((row: any) => ({
      description: `${row.name} checked in`,
      time: new Date(row.time).toLocaleTimeString()
    }));

    return NextResponse.json({
      totalMembers,
      activeMembers,
      todayCheckIns,
      totalRevenue,
      recentActivity
    });
  } catch (error: any) {
    console.error('Failed to get admin stats:', error);
    return NextResponse.json(
      { error: 'Failed to get statistics' },
      { status: 500 }
    );
  }
}
