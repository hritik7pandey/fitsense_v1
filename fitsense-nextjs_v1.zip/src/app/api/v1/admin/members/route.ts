import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';

// GET /api/v1/admin/members - Get all members
export async function GET(request: NextRequest) {
  const authResult = await authenticateRequest(request);
  if (authResult instanceof NextResponse) return authResult;

  const adminCheck = requireAdmin(authResult);
  if (adminCheck instanceof NextResponse) return adminCheck;

  try {
    const result = await query(`
      SELECT 
        u.id, u.name, u.email, u.phone, u.role, u."createdAt",
        COALESCE(u."isBlocked", false) as "isBlocked",
        m.id as membership_id, m.status as membership_status, m."startDate", m."endDate",
        p.id as plan_id, p.name as plan_name, p.price as plan_price
      FROM users u
      LEFT JOIN memberships m ON u.id = m."userId"
      LEFT JOIN plans p ON m."planId" = p.id
      WHERE u.role = 'MEMBER' OR u.role = 'ADMIN'
      ORDER BY u."createdAt" DESC
    `);

    const members = result.rows.map((row: any) => ({
      id: row.id,
      name: row.name,
      email: row.email,
      phone: row.phone,
      role: row.role,
      createdAt: row.createdAt,
      isBlocked: row.isBlocked,
      membership: row.membership_id ? {
        id: row.membership_id,
        status: row.membership_status,
        startDate: row.startDate,
        endDate: row.endDate,
        plan: row.plan_id ? {
          id: row.plan_id,
          name: row.plan_name,
          price: row.plan_price
        } : null
      } : null
    }));

    return NextResponse.json(members);
  } catch (error: any) {
    console.error('Failed to get members:', error);
    return NextResponse.json(
      { error: 'Failed to get members' },
      { status: 500 }
    );
  }
}
