import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, requireAdmin } from '@/lib/auth';
import { query, queryOne } from '@/lib/db';

// PATCH /api/v1/admin/members/[id]/block - Block or unblock a member
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const authResult = await authenticateRequest(request);
  if (authResult instanceof NextResponse) return authResult;

  const adminCheck = requireAdmin(authResult);
  if (adminCheck instanceof NextResponse) return adminCheck;

  try {
    const body = await request.json();
    const { isBlocked } = body;

    // Check if user exists
    const user = await queryOne('SELECT id, role FROM users WHERE id = $1', [id]);
    if (!user) {
      return NextResponse.json(
        { error: 'Member not found' },
        { status: 404 }
      );
    }

    // Prevent blocking admins
    if (user.role === 'ADMIN' && isBlocked) {
      return NextResponse.json(
        { error: 'Cannot block an admin user' },
        { status: 400 }
      );
    }

    // Add isBlocked column if it doesn't exist
    await query(`
      ALTER TABLE users ADD COLUMN IF NOT EXISTS "isBlocked" BOOLEAN DEFAULT FALSE
    `).catch(() => {});

    await query(`
      UPDATE users 
      SET "isBlocked" = $1, "updatedAt" = NOW()
      WHERE id = $2
    `, [isBlocked, id]);

    // If blocking, also update membership status
    if (isBlocked) {
      await query(`
        UPDATE memberships 
        SET status = 'BLOCKED', "updatedAt" = NOW()
        WHERE "userId" = $1 AND status = 'ACTIVE'
      `, [id]);
    } else {
      // If unblocking, restore membership if it was blocked and not expired
      await query(`
        UPDATE memberships 
        SET status = CASE 
          WHEN "endDate" > NOW() THEN 'ACTIVE'
          ELSE 'EXPIRED'
        END, "updatedAt" = NOW()
        WHERE "userId" = $1 AND status = 'BLOCKED'
      `, [id]);
    }

    return NextResponse.json({ 
      success: true, 
      isBlocked,
      message: isBlocked ? 'Member blocked successfully' : 'Member unblocked successfully'
    });
  } catch (error: any) {
    console.error('Failed to update block status:', error);
    return NextResponse.json(
      { error: error.message || 'Failed to update block status' },
      { status: 500 }
    );
  }
}
