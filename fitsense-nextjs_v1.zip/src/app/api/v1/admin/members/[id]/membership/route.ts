import { NextRequest, NextResponse } from 'next/server';
import { authenticateRequest, requireAdmin } from '@/lib/auth';
import { query } from '@/lib/db';
import { randomUUID } from 'crypto';

// POST /api/v1/admin/members/[id]/membership - Assign membership to a member
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const authResult = await authenticateRequest(request);
  if (authResult instanceof NextResponse) return authResult;

  const adminCheck = requireAdmin(authResult);
  if (adminCheck instanceof NextResponse) return adminCheck;

  try {
    const body = await request.json();
    const { planId } = body;

    if (!planId) {
      return NextResponse.json(
        { error: 'Plan ID is required' },
        { status: 400 }
      );
    }

    // Get plan details
    const planResult = await query('SELECT * FROM plans WHERE id = $1', [planId]);
    if (planResult.rows.length === 0) {
      return NextResponse.json(
        { error: 'Plan not found' },
        { status: 404 }
      );
    }

    const plan = planResult.rows[0];
    const startDate = new Date();
    const endDate = new Date();
    endDate.setDate(endDate.getDate() + plan.durationDays);

    // Check if user already has a membership
    const existingResult = await query(
      'SELECT id FROM memberships WHERE "userId" = $1',
      [id]
    );

    if (existingResult.rows.length > 0) {
      // Update existing membership
      await query(`
        UPDATE memberships 
        SET "planId" = $1, "startDate" = $2, "endDate" = $3, status = 'ACTIVE', "updatedAt" = NOW()
        WHERE "userId" = $4
      `, [planId, startDate, endDate, id]);
    } else {
      // Create new membership
      await query(`
        INSERT INTO memberships (id, "userId", "planId", "startDate", "endDate", status, "createdAt", "updatedAt")
        VALUES ($1, $2, $3, $4, $5, 'ACTIVE', NOW(), NOW())
      `, [randomUUID(), id, planId, startDate, endDate]);
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Failed to assign membership:', error);
    return NextResponse.json(
      { error: 'Failed to assign membership' },
      { status: 500 }
    );
  }
}

// DELETE /api/v1/admin/members/[id]/membership - Cancel member's membership
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const authResult = await authenticateRequest(request);
  if (authResult instanceof NextResponse) return authResult;

  const adminCheck = requireAdmin(authResult);
  if (adminCheck instanceof NextResponse) return adminCheck;

  try {
    await query(`
      UPDATE memberships 
      SET status = 'CANCELLED', "updatedAt" = NOW()
      WHERE "userId" = $1
    `, [id]);

    return NextResponse.json({ success: true });
  } catch (error: any) {
    console.error('Failed to cancel membership:', error);
    return NextResponse.json(
      { error: 'Failed to cancel membership' },
      { status: 500 }
    );
  }
}
