'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { GlassCard } from '@/components/ui/GlassCard';
import { 
  Users, CreditCard, Dumbbell, Utensils, Calendar, TrendingUp, 
  ChevronRight, Sparkles, Plus, UserPlus, FileText, Settings
} from 'lucide-react';
import { apiClient } from '@/lib/api-client';
import { motion } from 'framer-motion';

export default function AdminDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const data = await apiClient.get('/api/v1/admin/stats');
      setStats(data);
    } catch (error) {
      console.error('Failed to load stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const statCards = [
    { 
      label: 'Total Members', 
      value: stats?.totalMembers || 0, 
      icon: Users, 
      color: 'from-accent-blue to-blue-600',
      textColor: 'text-accent-blue'
    },
    { 
      label: 'Active Members', 
      value: stats?.activeMembers || 0, 
      icon: TrendingUp, 
      color: 'from-green-500 to-green-600',
      textColor: 'text-green-400'
    },
    { 
      label: 'Today\'s Check-ins', 
      value: stats?.todayCheckIns || 0, 
      icon: Calendar, 
      color: 'from-accent-purple to-purple-600',
      textColor: 'text-accent-purple'
    },
    { 
      label: 'Total Revenue', 
      value: `₹${stats?.totalRevenue || 0}`, 
      icon: CreditCard, 
      color: 'from-yellow-500 to-orange-500',
      textColor: 'text-yellow-400'
    },
  ];

  const quickActions = [
    { label: 'Members', desc: 'Manage all members', icon: Users, path: '/app/admin/members', color: 'text-accent-blue' },
    { label: 'Plans', desc: 'Membership plans', icon: CreditCard, path: '/app/admin/plans', color: 'text-green-400' },
    { label: 'Attendance', desc: 'View attendance', icon: Calendar, path: '/app/admin/attendance', color: 'text-accent-purple' },
    { label: 'Reports', desc: 'Analytics & exports', icon: FileText, path: '/app/admin/reports', color: 'text-yellow-400' },
  ];

  const aiTools = [
    { 
      label: 'AI Workout Generator', 
      desc: 'Create workouts for members', 
      icon: Dumbbell, 
      path: '/app/admin/workout/ai-generate',
      gradient: 'from-accent-blue/10 via-accent-purple/5 to-transparent'
    },
    { 
      label: 'AI Diet Planner', 
      desc: 'Generate diet for members', 
      icon: Utensils, 
      path: '/app/admin/diet/ai-generate',
      gradient: 'from-green-500/10 via-emerald-500/5 to-transparent'
    },
  ];

  const customTools = [
    { 
      label: 'Custom Workout', 
      desc: 'Create manual workout plan', 
      icon: Dumbbell, 
      path: '/app/admin/workout/create',
      gradient: 'from-accent-blue/10 via-blue-500/5 to-transparent'
    },
    { 
      label: 'Custom Diet', 
      desc: 'Create manual diet plan', 
      icon: Utensils, 
      path: '/app/admin/diet/create',
      gradient: 'from-green-500/10 via-teal-500/5 to-transparent'
    },
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="relative bg-gradient-to-b from-accent-purple/20 via-accent-blue/10 to-transparent pt-4 pb-8 px-4">
        <div className="absolute top-0 right-0 w-40 h-40 bg-accent-purple/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-accent-blue/10 rounded-full blur-3xl" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div className="flex items-center justify-between mb-2">
            <div>
              <h1 className="text-2xl font-bold text-white">Admin Dashboard</h1>
              <p className="text-sm text-white/50">Manage your fitness center</p>
            </div>
            <button
              onClick={() => router.push('/app/admin/members')}
              className="w-12 h-12 rounded-full bg-gradient-to-br from-accent-blue to-accent-purple flex items-center justify-center shadow-lg shadow-accent-purple/30"
            >
              <UserPlus size={20} className="text-white" />
            </button>
          </div>
        </motion.div>
      </div>

      <div className="px-4 -mt-2 space-y-6">
        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 gap-3"
        >
          {statCards.map((stat, index) => (
            <GlassCard key={index} className="!p-4">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${stat.color} flex items-center justify-center shadow-lg`}>
                  <stat.icon size={18} className="text-white" />
                </div>
              </div>
              <p className={`text-2xl font-bold ${stat.textColor}`}>
                {loading ? '-' : stat.value}
              </p>
              <p className="text-xs text-white/40">{stat.label}</p>
            </GlassCard>
          ))}
        </motion.div>

        {/* Quick Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-xs font-bold text-white/40 uppercase tracking-wider mb-3">Quick Actions</h3>
          <GlassCard className="!p-0 overflow-hidden">
            {quickActions.map((action, index) => (
              <button
                key={index}
                onClick={() => router.push(action.path)}
                className={`w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors ${index !== quickActions.length - 1 ? 'border-b border-white/5' : ''}`}
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${action.color}`}>
                    <action.icon size={18} />
                  </div>
                  <div className="text-left">
                    <p className="font-medium text-sm text-white">{action.label}</p>
                    <p className="text-xs text-white/40">{action.desc}</p>
                  </div>
                </div>
                <ChevronRight size={18} className="text-white/20" />
              </button>
            ))}
          </GlassCard>
        </motion.div>

        {/* AI Tools */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Sparkles size={14} className="text-accent-purple" />
            <h3 className="text-xs font-bold text-white/40 uppercase tracking-wider">AI Tools</h3>
          </div>
          <div className="grid grid-cols-1 gap-3">
            {aiTools.map((tool, index) => (
              <button
                key={index}
                onClick={() => router.push(tool.path)}
                className={`p-4 rounded-2xl bg-gradient-to-r ${tool.gradient} border border-white/5 text-left group active:scale-[0.98] transition-transform`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                      <tool.icon size={20} className="text-accent-purple" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm text-white">{tool.label}</p>
                      <p className="text-xs text-white/40">{tool.desc}</p>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                    <ChevronRight size={16} className="text-white/40" />
                  </div>
                </div>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Custom Plan Tools */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
        >
          <div className="flex items-center gap-2 mb-3">
            <Plus size={14} className="text-accent-blue" />
            <h3 className="text-xs font-bold text-white/40 uppercase tracking-wider">Custom Plans</h3>
          </div>
          <div className="grid grid-cols-2 gap-3">
            {customTools.map((tool, index) => (
              <button
                key={index}
                onClick={() => router.push(tool.path)}
                className={`p-4 rounded-2xl bg-gradient-to-r ${tool.gradient} border border-white/5 text-left group active:scale-[0.98] transition-transform`}
              >
                <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center mb-2">
                  <tool.icon size={18} className="text-accent-blue" />
                </div>
                <p className="font-semibold text-sm text-white">{tool.label}</p>
                <p className="text-[10px] text-white/40">{tool.desc}</p>
              </button>
            ))}
          </div>
        </motion.div>

        {/* Recent Activity */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h3 className="text-xs font-bold text-white/40 uppercase tracking-wider mb-3">Recent Activity</h3>
          <GlassCard className="!p-4">
            <div className="space-y-3">
              {stats?.recentActivity?.length > 0 ? (
                stats.recentActivity.slice(0, 5).map((activity: any, index: number) => (
                  <div key={index} className="flex items-center gap-3 py-2 border-b border-white/5 last:border-0">
                    <div className="w-8 h-8 rounded-full bg-accent-blue/10 flex items-center justify-center">
                      <Users size={14} className="text-accent-blue" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-white">{activity.description}</p>
                      <p className="text-xs text-white/40">{activity.time}</p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-4">
                  <p className="text-white/40 text-sm">No recent activity</p>
                </div>
              )}
            </div>
          </GlassCard>
        </motion.div>
      </div>
    </div>
  );
}
