'use client';

import React, { useState, useEffect } from 'react';
import { GlassCard } from '@/components/ui/GlassCard';
import { CreditCard, Crown, Calendar, Clock, Shield, Sparkles, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { apiClient } from '@/lib/api-client';
import { useAuth } from '@/lib/auth-context';
import { motion } from 'framer-motion';

export default function MembershipPage() {
  const { user } = useAuth();
  const [membership, setMembership] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadMembership();
  }, []);

  const loadMembership = async () => {
    try {
      const data = await apiClient.get('/api/v1/membership/my-membership');
      setMembership(data);
    } catch (error: any) {
      console.error('Failed to load membership:', error);
      setMembership(null);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-IN', { 
      year: 'numeric', 
      month: 'short', 
      day: '2-digit' 
    });
  };

  const getDaysRemaining = () => {
    if (!membership?.endDate) return 0;
    const end = new Date(membership.endDate);
    const now = new Date();
    const diff = Math.ceil((end.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
    return Math.max(0, diff);
  };

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'ACTIVE': return { 
        color: 'text-green-400', 
        bg: 'bg-green-500/20', 
        border: 'border-green-500/30',
        icon: CheckCircle,
        label: 'Active'
      };
      case 'EXPIRED': return { 
        color: 'text-red-400', 
        bg: 'bg-red-500/20', 
        border: 'border-red-500/30',
        icon: AlertCircle,
        label: 'Expired'
      };
      case 'BLOCKED': return { 
        color: 'text-yellow-400', 
        bg: 'bg-yellow-500/20', 
        border: 'border-yellow-500/30',
        icon: Shield,
        label: 'Blocked'
      };
      default: return { 
        color: 'text-gray-400', 
        bg: 'bg-gray-500/20', 
        border: 'border-gray-500/30',
        icon: Clock,
        label: status
      };
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="animate-spin text-accent-blue" size={32} />
      </div>
    );
  }

  if (!membership || !membership.plan) {
    return (
      <div className="min-h-screen pb-24 px-4 pt-8">
        <h2 className="text-2xl font-bold mb-6 text-white">Membership</h2>
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
        >
          <GlassCard className="text-center py-12">
            <div className="w-20 h-20 rounded-full bg-accent-blue/10 flex items-center justify-center mx-auto mb-4">
              <CreditCard size={32} className="text-accent-blue/50" />
            </div>
            <h3 className="font-bold text-lg mb-2 text-white">No Active Membership</h3>
            <p className="text-white/50 text-sm mb-2">You don't have an active membership plan</p>
            <p className="text-white/40 text-xs">Contact your gym administrator to get started</p>
          </GlassCard>
        </motion.div>
      </div>
    );
  }

  const statusConfig = getStatusConfig(membership.status);
  const daysRemaining = getDaysRemaining();
  const StatusIcon = statusConfig.icon;

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="relative bg-gradient-to-b from-accent-purple/20 via-accent-blue/10 to-transparent pt-4 pb-8 px-4">
        <div className="absolute top-0 right-0 w-40 h-40 bg-accent-purple/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-32 h-32 bg-accent-blue/10 rounded-full blur-3xl" />
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-2xl font-bold mb-1 text-white">Membership</h1>
          <p className="text-sm text-white/50">Your gym access card</p>
        </motion.div>
      </div>

      <div className="px-4 -mt-2 space-y-6">
        {/* Premium Membership Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="relative rounded-3xl overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-accent-purple via-accent-blue to-accent-glow opacity-90" />
            <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0djItSDI0di0yaDEyek0zNiAyNHYySDI0di0yaDEyeiIvPjwvZz48L2c+PC9zdmc+')] opacity-30" />
            
            <div className="relative p-6">
              <div className="flex items-start justify-between mb-8">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Crown size={20} className="text-yellow-300" />
                    <span className="text-xs font-bold text-white/80 uppercase tracking-wider">FitSense</span>
                  </div>
                  <h3 className="text-2xl font-bold text-white">{membership.plan.name}</h3>
                </div>
                <div className={`px-3 py-1.5 rounded-full ${statusConfig.bg} ${statusConfig.border} border flex items-center gap-1.5`}>
                  <StatusIcon size={14} className={statusConfig.color} />
                  <span className={`text-xs font-bold ${statusConfig.color}`}>{statusConfig.label}</span>
                </div>
              </div>

              <div className="mb-8">
                <p className="text-xs text-white/50 mb-1">MEMBER</p>
                <p className="text-lg font-semibold text-white">{user?.name || 'Member'}</p>
              </div>

              <div className="flex items-end justify-between">
                <div>
                  <p className="text-xs text-white/50 mb-1">VALID UNTIL</p>
                  <p className="text-lg font-bold text-white">{formatDate(membership.endDate)}</p>
                </div>
                <div className="text-right">
                  <p className="text-3xl font-bold text-white">₹{membership.plan.price}</p>
                  <p className="text-xs text-white/60">/{membership.plan.durationDays} days</p>
                </div>
              </div>

              <div className="absolute top-4 right-4 w-16 h-16 rounded-full border border-white/10" />
              <div className="absolute top-8 right-8 w-8 h-8 rounded-full border border-white/10" />
            </div>
          </div>
        </motion.div>

        {/* Stats Grid */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 gap-3"
        >
          <GlassCard className="!p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-green-500/20 flex items-center justify-center">
                <Calendar size={20} className="text-green-400" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{daysRemaining}</p>
                <p className="text-xs text-white/50">Days Left</p>
              </div>
            </div>
          </GlassCard>
          
          <GlassCard className="!p-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-accent-blue/20 flex items-center justify-center">
                <Clock size={20} className="text-accent-blue" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{membership.plan.durationDays}</p>
                <p className="text-xs text-white/50">Total Days</p>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Plan Details */}
        {membership.plan.description && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <GlassCard className="!p-4">
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-xl bg-accent-purple/20 flex items-center justify-center flex-shrink-0">
                  <Sparkles size={18} className="text-accent-purple" />
                </div>
                <div>
                  <h4 className="font-bold text-sm mb-1 text-white">Plan Benefits</h4>
                  <p className="text-sm text-white/60">{membership.plan.description}</p>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        )}

        {/* Membership Timeline */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <h3 className="font-bold text-sm mb-3 text-white/70">Membership Period</h3>
          <GlassCard className="!p-4">
            <div className="flex items-center justify-between">
              <div className="text-center">
                <p className="text-xs text-white/40 mb-1">Started</p>
                <p className="font-semibold text-sm text-white">{formatDate(membership.startDate)}</p>
              </div>
              <div className="flex-1 mx-4 h-1 bg-white/10 rounded-full relative overflow-hidden">
                <div 
                  className="absolute inset-y-0 left-0 bg-gradient-to-r from-green-500 to-accent-blue rounded-full"
                  style={{ width: `${Math.min(100, Math.max(0, 100 - (daysRemaining / membership.plan.durationDays * 100)))}%` }}
                />
              </div>
              <div className="text-center">
                <p className="text-xs text-white/40 mb-1">Expires</p>
                <p className="font-semibold text-sm text-white">{formatDate(membership.endDate)}</p>
              </div>
            </div>
          </GlassCard>
        </motion.div>

        {/* Contact Admin */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="text-center pt-4"
        >
          <p className="text-xs text-white/40">
            Need to renew or upgrade? Contact your gym administrator
          </p>
        </motion.div>
      </div>
    </div>
  );
}
