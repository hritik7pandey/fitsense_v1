'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { GlassCard } from '@/components/ui/GlassCard';
import { GlassButton } from '@/components/ui/GlassButton';
import { DEFAULT_AVATAR } from '@/lib/constants';
import { User, Shield, ChevronRight, LogOut, Lock, Crown, Dumbbell, Utensils, Camera } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';
import { apiClient } from '@/lib/api-client';
import { motion } from 'framer-motion';

export default function ProfilePage() {
  const router = useRouter();
  const { user, logout } = useAuth();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProfile();
  }, []);

  const loadProfile = async () => {
    try {
      const data = await apiClient.get('/api/v1/users/profile');
      setProfile(data);
    } catch (error: any) {
      console.error('Failed to load profile:', error);
      setProfile(user);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  const sections = [
    { 
      title: "Account",
      items: [
        { icon: User, label: "Personal Details", desc: "Update your info", path: "/app/profile/edit", color: "text-accent-blue" },
        { icon: Lock, label: "Security", desc: "Password & privacy", path: "/app/profile/security", color: "text-yellow-400" },
      ]
    },
    ...(user?.role === 'ADMIN' ? [{
      title: "Admin",
      items: [
        { icon: Shield, label: "Admin Dashboard", desc: "Manage gym", path: "/app/admin", color: "text-accent-purple" },
      ]
    }] : [])
  ];

  return (
    <div className="min-h-screen pb-24">
      {/* Premium Header with Gradient */}
      <div className="relative bg-gradient-to-b from-accent-blue/20 via-accent-purple/10 to-transparent pt-6 pb-12 px-4">
        <div className="absolute top-0 right-0 w-32 h-32 bg-accent-blue/10 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-40 h-40 bg-accent-purple/10 rounded-full blur-3xl" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center relative z-10"
        >
          {/* Avatar with Edit Button */}
          <div className="relative mb-4">
            <div className="w-28 h-28 rounded-full p-1 bg-gradient-to-br from-accent-blue via-accent-purple to-accent-glow">
              <div className="w-full h-full rounded-full bg-primary p-1">
                <img src={profile?.avatarUrl || DEFAULT_AVATAR} className="w-full h-full rounded-full object-cover" alt="Profile" />
              </div>
            </div>
            <button 
              onClick={() => router.push('/app/profile/edit')}
              className="absolute bottom-1 right-1 w-9 h-9 bg-accent-blue rounded-full flex items-center justify-center text-primary shadow-lg shadow-accent-blue/30 border-2 border-primary"
            >
              <Camera size={16} />
            </button>
          </div>
          
          {/* Name & Email */}
          <h2 className="text-2xl font-bold mb-1 text-white">{user?.name || 'User'}</h2>
          <p className="text-white/50 text-sm mb-3">{user?.email}</p>
          
          {/* Role Badge */}
          <div className="flex items-center gap-2 px-3 py-1.5 bg-white/5 backdrop-blur-md rounded-full border border-white/10">
            <Crown size={14} className="text-yellow-400" />
            <span className="text-xs font-medium text-white">{user?.role === 'ADMIN' ? 'Administrator' : 'Member'}</span>
          </div>
        </motion.div>
      </div>

      <div className="px-4 -mt-4 space-y-6">
        {/* Stats Cards */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-3"
        >
          <GlassCard className="!p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-accent-blue/20 flex items-center justify-center mx-auto mb-2">
              <span className="text-accent-blue font-bold">{profile?.heightCm || '--'}</span>
            </div>
            <p className="text-[10px] text-white/40 uppercase tracking-wider">Height (cm)</p>
          </GlassCard>
          
          <GlassCard className="!p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-green-500/20 flex items-center justify-center mx-auto mb-2">
              <span className="text-green-400 font-bold">{profile?.weightKg || '--'}</span>
            </div>
            <p className="text-[10px] text-white/40 uppercase tracking-wider">Weight (kg)</p>
          </GlassCard>
          
          <GlassCard className="!p-4 text-center">
            <div className="w-10 h-10 rounded-xl bg-accent-purple/20 flex items-center justify-center mx-auto mb-2">
              <span className="text-accent-purple font-bold">{profile?.age || '--'}</span>
            </div>
            <p className="text-[10px] text-white/40 uppercase tracking-wider">Age (yrs)</p>
          </GlassCard>
        </motion.div>

        {/* Quick Actions */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-2 gap-3"
        >
          <button 
            onClick={() => router.push('/app/workout')}
            className="p-4 rounded-2xl bg-gradient-to-br from-accent-blue/10 to-transparent border border-accent-blue/20 text-left group active:scale-[0.98] transition-transform"
          >
            <Dumbbell size={20} className="text-accent-blue mb-2" />
            <p className="font-semibold text-sm text-white">My Workouts</p>
            <p className="text-xs text-white/40">View plans</p>
          </button>
          
          <button 
            onClick={() => router.push('/app/diet')}
            className="p-4 rounded-2xl bg-gradient-to-br from-green-500/10 to-transparent border border-green-500/20 text-left group active:scale-[0.98] transition-transform"
          >
            <Utensils size={20} className="text-green-400 mb-2" />
            <p className="font-semibold text-sm text-white">My Diet</p>
            <p className="text-xs text-white/40">Meal plans</p>
          </button>
        </motion.div>

        {/* Settings Sections */}
        {sections.map((section, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
          >
            <h3 className="text-xs font-bold text-white/30 uppercase mb-3 ml-1 tracking-wider">{section.title}</h3>
            <GlassCard className="!p-0 overflow-hidden">
              {section.items.map((item, j) => (
                <button 
                  key={j}
                  onClick={() => router.push(item.path)}
                  className={`w-full p-4 flex items-center justify-between hover:bg-white/5 transition-colors ${j !== section.items.length - 1 ? 'border-b border-white/5' : ''}`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center ${item.color}`}>
                      <item.icon size={18} />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-sm text-white">{item.label}</p>
                      <p className="text-xs text-white/40">{item.desc}</p>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-white/20" />
                </button>
              ))}
            </GlassCard>
          </motion.div>
        ))}

        {/* Logout Button */}
        <motion.button 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          onClick={handleLogout} 
          className="w-full py-4 flex items-center justify-center gap-3 text-red-400 bg-red-500/5 hover:bg-red-500/10 rounded-2xl border border-red-500/10 transition-colors"
        >
          <LogOut size={18} />
          <span className="font-medium">Sign Out</span>
        </motion.button>
      </div>
    </div>
  );
}
