import type { Metadata, Viewport } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from './providers';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'FitSense Fitness Hub',
  description: 'AI-powered fitness platform with personalized workouts and diet plans',
  keywords: ['fitness', 'gym', 'workout', 'diet', 'AI', 'health'],
  authors: [{ name: 'FitSense Team' }],
  icons: {
    icon: '/favicon.ico',
  },
  manifest: '/manifest.json',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: '#0a0a1a',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.className} antialiased bg-primary text-white`}>
        <Providers>
          {children}
        </Providers>
      </body>
    </html>
  );
}
