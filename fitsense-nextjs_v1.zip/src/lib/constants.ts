// Default avatar URL
export const DEFAULT_AVATAR = 'https://api.dicebear.com/7.x/avataaars/svg?seed=FitSense';

// App name
export const APP_NAME = 'FitSense Fitness Hub';

// Workout types
export const WORKOUT_TYPES = [
  'strength',
  'cardio', 
  'hiit',
  'yoga',
  'flexibility',
  'endurance',
  'full-body',
] as const;

// Diet types
export const DIET_TYPES = [
  'weight_loss',
  'muscle_gain',
  'maintenance',
  'keto',
  'vegan',
  'high_protein',
] as const;

// Difficulty levels
export const DIFFICULTY_LEVELS = [
  'beginner',
  'intermediate',
  'advanced',
] as const;

// Activity levels
export const ACTIVITY_LEVELS = [
  'sedentary',
  'lightly_active',
  'moderately_active',
  'very_active',
  'extremely_active',
] as const;

// Gender options
export const GENDER_OPTIONS = [
  { value: 'MALE', label: 'Male' },
  { value: 'FEMALE', label: 'Female' },
  { value: 'OTHER', label: 'Other' },
] as const;

// Membership statuses
export const MEMBERSHIP_STATUSES = {
  ACTIVE: 'ACTIVE',
  EXPIRED: 'EXPIRED',
  BLOCKED: 'BLOCKED',
  CANCELLED: 'CANCELLED',
} as const;

// Role types
export const ROLES = {
  ADMIN: 'ADMIN',
  USER: 'USER',
} as const;

// Notification types
export const NOTIFICATION_TYPES = [
  'WORKOUT',
  'DIET',
  'MEMBERSHIP',
  'GENERAL',
  'ALERT',
] as const;
