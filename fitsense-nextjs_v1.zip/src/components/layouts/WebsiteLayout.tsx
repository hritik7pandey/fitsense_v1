'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { Dumbbell } from 'lucide-react';

export function WebsiteLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-primary text-white font-sans selection:bg-accent-blue/30">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-primary/80 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 sm:h-20 flex items-center justify-between">
          <button onClick={() => router.push('/landing')} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
            <div className="w-8 h-8 bg-gradient-to-tr from-accent-blue to-accent-purple rounded-lg flex items-center justify-center shadow-lg shadow-accent-blue/20">
               <Dumbbell size={18} className="text-white" />
            </div>
            <span className="font-bold text-lg sm:text-xl tracking-tight">FitSense</span>
          </button>
          
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-white/70">
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#testimonials" className="hover:text-white transition-colors">Testimonials</a>
            <a href="#pricing" className="hover:text-white transition-colors">Pricing</a>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
             <button 
               onClick={() => router.push('/login')} 
               className="text-xs sm:text-sm font-medium hover:text-accent-blue transition-colors px-2 sm:px-0"
             >
               Log In
             </button>
             <button 
               onClick={() => router.push('/register')} 
               className="bg-gradient-to-r from-accent-blue to-accent-purple text-white px-4 sm:px-5 py-2 rounded-full text-xs sm:text-sm font-bold hover:shadow-lg hover:shadow-accent-blue/30 transition-all"
             >
               Join Now
             </button>
          </div>
        </div>
      </nav>

      <main className="pt-20">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-black/40 pt-20 pb-10 mt-20">
         <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
            <div>
              <h4 className="font-bold text-lg mb-4">FitSense</h4>
              <p className="text-white/40 text-sm leading-relaxed">The premium digital fitness experience for elite performers.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Product</h4>
              <ul className="space-y-2 text-sm text-white/50">
                <li>Features</li>
                <li>Pricing</li>
                <li>AI Coach</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Company</h4>
              <ul className="space-y-2 text-sm text-white/50">
                <li>About</li>
                <li>Careers</li>
                <li>Contact</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm text-white/50">
                <li>Privacy</li>
                <li>Terms</li>
              </ul>
            </div>
         </div>
         <div className="text-center text-white/20 text-xs">
           © 2024 FitSense Fitness Hub. All rights reserved.
         </div>
      </footer>
    </div>
  );
}
