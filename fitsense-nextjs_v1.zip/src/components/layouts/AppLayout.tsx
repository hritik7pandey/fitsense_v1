'use client';

import React, { useEffect, useState } from 'react';
import { usePathname, useRouter } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Home, Dumbbell, Calendar, User, CreditCard, LayoutDashboard, Users, FileBarChart, Utensils, LogOut, Bell } from 'lucide-react';
import { useAuth } from '@/lib/auth-context';

interface NavItem {
  id: string;
  label: string;
  icon: React.ElementType;
  path: string;
}

const DEFAULT_AVATAR = 'https://ui-avatars.com/api/?name=User&background=4F9CFF&color=fff';

export function AppLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const router = useRouter();
  const { user, logout } = useAuth();
  const [isMobileNavVisible, setIsMobileNavVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  const memberNavItems: NavItem[] = [
    { id: 'home', label: 'Home', icon: Home, path: '/app/home' },
    { id: 'workout', label: 'Workout', icon: Dumbbell, path: '/app/workout' },
    { id: 'diet', label: 'Diet', icon: Utensils, path: '/app/diet' },
    { id: 'membership', label: 'Card', icon: CreditCard, path: '/app/membership' },
    { id: 'profile', label: 'Profile', icon: User, path: '/app/profile' },
  ];

  const adminNavItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard, path: '/app/admin' },
    { id: 'members', label: 'Members', icon: Users, path: '/app/admin/members' },
    { id: 'attendance', label: 'Attendance', icon: Calendar, path: '/app/admin/attendance' },
    { id: 'plans', label: 'Plans', icon: Dumbbell, path: '/app/admin/plans' },
    { id: 'reports', label: 'Reports', icon: FileBarChart, path: '/app/admin/reports' },
  ];

  const navItems = user?.role === 'ADMIN' ? adminNavItems : memberNavItems;

  const handleLogout = async () => {
    await logout();
    router.push('/login');
  };

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      if (currentScrollY > lastScrollY && currentScrollY > 50) {
        setIsMobileNavVisible(false);
      } else {
        setIsMobileNavVisible(true);
      }
      setLastScrollY(currentScrollY);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  return (
    <div className="min-h-screen bg-primary text-white flex font-sans">
      {/* Background Ambience */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-accent-blue/5 rounded-full blur-[120px]" />
        <div className="absolute bottom-0 right-1/4 w-[600px] h-[600px] bg-accent-purple/5 rounded-full blur-[120px]" />
      </div>

      {/* DESKTOP SIDEBAR */}
      <aside className="hidden lg:flex flex-col w-64 h-screen sticky top-0 border-r border-white/5 bg-black/20 backdrop-blur-xl">
        <div className="p-8 flex items-center gap-3">
          <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center">
            <Dumbbell className="text-primary" size={20} />
          </div>
          <span className="font-bold text-xl tracking-tight">FitSense</span>
        </div>

        <nav className="flex-1 px-4 space-y-2">
          {navItems.map((item) => {
            const isActive = pathname.startsWith(item.path);
            return (
              <button
                key={item.id}
                onClick={() => router.push(item.path)}
                className={`w-full flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-300 ${
                  isActive
                    ? 'bg-accent-blue/10 text-accent-blue border border-accent-blue/20'
                    : 'text-white/60 hover:bg-white/5 hover:text-white'
                }`}
              >
                <item.icon size={20} />
                <span className="font-medium text-sm">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-white/5">
          <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors">
            <LogOut size={20} />
            <span className="font-medium text-sm">Sign Out</span>
          </button>
        </div>
      </aside>

      {/* MAIN CONTENT */}
      <main className="flex-1 min-w-0 flex flex-col relative">
        {/* Mobile Top Bar */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 border-b border-white/5 bg-primary/80 backdrop-blur-md sticky top-0 z-40">
          <button onClick={() => router.push('/app/home')} className="flex items-center gap-2">
            <div className="w-8 h-8 bg-accent-blue rounded-lg flex items-center justify-center">
              <Dumbbell className="text-primary" size={18} />
            </div>
            <span className="font-bold text-lg tracking-tight">FitSense</span>
          </button>
          <div className="flex items-center gap-4">
            <button onClick={() => router.push('/app/notifications')} className="relative text-white/60 hover:text-white transition-colors">
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent-blue rounded-full" />
            </button>
            <button onClick={() => router.push('/app/profile')}>
              <img src={user?.profileImage || DEFAULT_AVATAR} className="w-8 h-8 rounded-full border border-white/10" alt="Profile" />
            </button>
          </div>
        </header>

        {/* Desktop Top Bar */}
        <header className="hidden lg:flex items-center justify-between px-8 py-4 border-b border-white/5 bg-primary/50 backdrop-blur-md sticky top-0 z-40">
          <h2 className="font-bold text-lg capitalize">{pathname.split('/').pop()?.replace('-', ' ')}</h2>
          <div className="flex items-center gap-6">
            <button 
              onClick={() => router.push('/app/notifications')}
              className="relative text-white/60 hover:text-white transition-colors"
            >
              <Bell size={20} />
              <span className="absolute -top-1 -right-1 w-2 h-2 bg-accent-blue rounded-full" />
            </button>
            <div className="flex items-center gap-3 pl-6 border-l border-white/10">
              <div className="text-right">
                <p className="text-sm font-bold">{user?.name || 'User'}</p>
                <p className="text-xs text-white/50">{user?.role || 'MEMBER'}</p>
              </div>
              <img src={user?.profileImage || DEFAULT_AVATAR} className="w-10 h-10 rounded-full border border-white/10" alt="Profile" />
            </div>
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 w-full max-w-7xl mx-auto p-4 md:p-8 pb-28 lg:pb-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={pathname}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      {/* MOBILE BOTTOM NAV */}
      <motion.nav
        initial={{ y: 0 }}
        animate={{ y: isMobileNavVisible ? 0 : 100 }}
        transition={{ duration: 0.3 }}
        className="lg:hidden fixed bottom-0 left-0 right-0 z-50 px-4 pb-6 pt-2 pointer-events-none"
      >
        <div className="mx-auto max-w-md pointer-events-auto">
          <div className="bg-black/80 backdrop-blur-2xl border border-white/10 rounded-2xl px-2 py-4 flex justify-between items-center shadow-2xl">
            {navItems.map((item) => {
              const isActive = pathname.startsWith(item.path);
              return (
                <button
                  key={item.id}
                  onClick={() => router.push(item.path)}
                  className="relative flex flex-col items-center justify-center flex-1 h-12"
                >
                  <motion.div
                    animate={{
                      scale: isActive ? 1.1 : 1,
                      color: isActive ? '#4F9CFF' : '#6B7280'
                    }}
                    className="relative z-10 flex flex-col items-center gap-1"
                  >
                    <item.icon size={22} strokeWidth={isActive ? 2.5 : 2} />
                    <span className="text-[10px] font-medium">{item.label}</span>
                  </motion.div>
                  
                  {isActive && (
                    <motion.div
                      layoutId="activeTab"
                      className="absolute -bottom-2 w-8 h-1 bg-accent-blue rounded-full shadow-[0_0_10px_rgba(79,156,255,0.6)]"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </motion.nav>
    </div>
  );
}
