'use client';

import React from 'react';
import { motion } from 'framer-motion';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  delay?: number;
  onClick?: () => void;
  noPadding?: boolean;
  variant?: 'default' | 'elevated' | 'subtle';
}

export function GlassCard({ 
  children, 
  className = '', 
  delay = 0,
  onClick,
  noPadding = false,
  variant = 'default'
}: GlassCardProps) {
  const variants = {
    default: `
      bg-gradient-to-br from-white/[0.08] via-white/[0.04] to-transparent
      border border-white/[0.08]
      shadow-[0_8px_32px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.1)]
    `,
    elevated: `
      bg-gradient-to-br from-white/[0.12] via-white/[0.06] to-white/[0.02]
      border border-white/[0.12]
      shadow-[0_12px_40px_rgba(0,0,0,0.4),inset_0_1px_0_rgba(255,255,255,0.15)]
    `,
    subtle: `
      bg-white/[0.04]
      border border-white/[0.05]
      shadow-[0_4px_16px_rgba(0,0,0,0.2)]
    `
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, delay: delay, ease: [0.25, 0.46, 0.45, 0.94] }}
      whileTap={onClick ? { scale: 0.98 } : undefined}
      onClick={onClick}
      className={`
        relative overflow-hidden
        backdrop-blur-xl
        rounded-2xl
        ${variants[variant]}
        ${noPadding ? '' : 'p-6'}
        ${onClick ? 'cursor-pointer hover:border-accent-blue/30 hover:bg-white/[0.06] hover:shadow-[0_8px_32px_rgba(79,156,255,0.1)] active:scale-[0.98] transition-all duration-200' : ''}
        ${className}
      `}
    >
      {/* Top highlight edge - liquid glass effect */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/25 to-transparent" />
      
      {/* Liquid glass reflection - subtle top glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-white/[0.06] to-transparent h-1/3 pointer-events-none" />
      
      {/* Bottom shadow for depth */}
      <div className="absolute inset-x-0 bottom-0 h-px bg-gradient-to-r from-transparent via-black/20 to-transparent" />
      
      {/* Content */}
      <div className="relative z-10">
        {children}
      </div>
    </motion.div>
  );
}
