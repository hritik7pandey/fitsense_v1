'use client';

import React from 'react';
import { motion, HTMLMotionProps } from 'framer-motion';

type GlassButtonProps = {
  variant?: 'primary' | 'glass' | 'outline' | 'danger' | 'success';
  fullWidth?: boolean;
  size?: 'sm' | 'md' | 'lg';
  children?: React.ReactNode;
  className?: string;
  disabled?: boolean;
  onClick?: () => void;
  type?: 'button' | 'submit' | 'reset';
}

export function GlassButton({ 
  children, 
  className = '', 
  variant = 'primary', 
  fullWidth = false,
  size = 'md',
  disabled,
  onClick,
  type = 'button',
}: GlassButtonProps) {
  
  const baseClasses = `
    relative rounded-2xl font-semibold 
    transition-all duration-200 
    flex items-center justify-center gap-2 
    overflow-hidden group 
    disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
    active:scale-[0.97]
  `;
  
  const sizeClasses = {
    sm: 'px-4 py-2.5 text-xs',
    md: 'px-6 py-3.5 text-sm',
    lg: 'px-8 py-4.5 text-base'
  };

  const variants = {
    primary: `
      bg-gradient-to-r from-accent-blue via-accent-glow to-accent-blue 
      bg-[length:200%_100%] bg-left
      text-primary font-bold
      shadow-[0_4px_20px_rgba(79,156,255,0.4),inset_0_1px_0_rgba(255,255,255,0.25)]
      hover:bg-right hover:shadow-[0_6px_30px_rgba(79,156,255,0.5)]
      border border-accent-blue/20
    `,
    glass: `
      bg-white/[0.08] backdrop-blur-xl 
      border border-white/[0.12] 
      text-white 
      shadow-[inset_0_1px_0_rgba(255,255,255,0.1),0_4px_16px_rgba(0,0,0,0.2)]
      hover:bg-white/[0.12] hover:border-white/20
    `,
    outline: `
      bg-transparent backdrop-blur-md 
      border-2 border-accent-blue/50 
      text-accent-blue 
      hover:bg-accent-blue/10 hover:border-accent-blue
      shadow-[0_0_20px_rgba(79,156,255,0.1)]
    `,
    danger: `
      bg-red-500/10 backdrop-blur-md 
      border border-red-500/30 
      text-red-400 
      hover:bg-red-500/20 hover:border-red-500/50
    `,
    success: `
      bg-gradient-to-r from-green-500 to-emerald-600
      text-white font-bold
      shadow-[0_4px_20px_rgba(34,197,94,0.4),inset_0_1px_0_rgba(255,255,255,0.25)]
      hover:shadow-[0_6px_30px_rgba(34,197,94,0.5)]
      border border-green-400/20
    `
  };

  return (
    <motion.button
      whileHover={disabled ? {} : { scale: 1.02 }}
      whileTap={disabled ? {} : { scale: 0.97 }}
      transition={{ duration: 0.15 }}
      disabled={disabled}
      type={type}
      onClick={onClick}
      className={`${baseClasses} ${variants[variant]} ${sizeClasses[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
    >
      {/* Content */}
      <span className="relative z-10 flex items-center gap-2">{children}</span>
      
      {/* Shine effect for primary and success buttons */}
      {(variant === 'primary' || variant === 'success') && !disabled && (
        <div className="absolute inset-0 -translate-x-full group-hover:translate-x-full transition-transform duration-700 bg-gradient-to-r from-transparent via-white/20 to-transparent z-0" />
      )}
      
      {/* Top highlight */}
      <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/30 to-transparent" />
    </motion.button>
  );
}
