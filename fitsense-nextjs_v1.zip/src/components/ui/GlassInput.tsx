'use client';

import React, { useState, useEffect } from 'react';

interface GlassInputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'size'> {
  label: string;
  icon?: React.ReactNode;
  error?: string;
}

export function GlassInput({ 
  label, 
  icon, 
  error,
  className = '', 
  value, 
  ...props 
}: GlassInputProps) {
  const [isFocused, setIsFocused] = useState(false);
  const [hasValue, setHasValue] = useState(!!value);

  useEffect(() => {
    setHasValue(!!value && String(value).length > 0);
  }, [value]);

  const isFloating = isFocused || hasValue;

  return (
    <div className={`relative mb-4 ${className}`}>
      <div className="relative">
        <input
          {...props}
          value={value}
          className={`
            w-full bg-white/[0.04] backdrop-blur-xl
            border rounded-2xl 
            px-4 pt-6 pb-2.5
            text-white text-base
            placeholder-transparent 
            focus:outline-none focus:bg-white/[0.06]
            transition-all duration-200
            shadow-[inset_0_1px_0_rgba(255,255,255,0.05),0_4px_16px_rgba(0,0,0,0.1)]
            ${error 
              ? 'border-red-500/50 focus:border-red-500' 
              : 'border-white/[0.08] focus:border-accent-blue/50'
            }
            ${icon ? 'pr-12' : ''}
          `}
          onFocus={(e: React.FocusEvent<HTMLInputElement>) => {
            setIsFocused(true);
            props.onFocus?.(e);
          }}
          onBlur={(e: React.FocusEvent<HTMLInputElement>) => {
            setIsFocused(false);
            setHasValue(e.target.value.length > 0);
            props.onBlur?.(e);
          }}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
            setHasValue(e.target.value.length > 0);
            props.onChange?.(e);
          }}
        />
        
        {/* Floating Label */}
        <label
          className={`
            absolute left-4 transition-all duration-200 pointer-events-none
            ${isFloating 
              ? 'top-2 text-[10px] font-semibold tracking-wider uppercase' 
              : 'top-1/2 -translate-y-1/2 text-sm'}
            ${error 
              ? 'text-red-400' 
              : isFloating 
                ? 'text-accent-blue' 
                : 'text-white/40'
            }
          `}
        >
          {label}
        </label>
        
        {/* Icon */}
        {icon && (
          <div className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors ${isFocused ? 'text-accent-blue' : 'text-white/30'}`}>
            {icon}
          </div>
        )}
        
        {/* Top highlight */}
        <div className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/10 to-transparent rounded-t-2xl" />
      </div>
      
      {/* Error Message */}
      {error && (
        <p className="mt-1.5 text-xs text-red-400 ml-1">{error}</p>
      )}
    </div>
  );
}
