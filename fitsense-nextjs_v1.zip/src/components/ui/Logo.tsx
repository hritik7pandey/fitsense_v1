'use client';

import React from 'react';
import { Dumbbell } from 'lucide-react';

interface LogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  onClick?: () => void;
  className?: string;
}

export function Logo({ 
  size = 'md', 
  showText = true, 
  onClick,
  className = '' 
}: LogoProps) {
  const sizes = {
    sm: { icon: 16, text: 'text-base', container: 'w-6 h-6' },
    md: { icon: 18, text: 'text-lg', container: 'w-8 h-8' },
    lg: { icon: 24, text: 'text-2xl', container: 'w-12 h-12' }
  };

  const config = sizes[size];

  const content = (
    <>
      <div className={`${config.container} bg-gradient-to-tr from-accent-blue to-accent-purple rounded-lg flex items-center justify-center shadow-lg shadow-accent-blue/20`}>
        <Dumbbell size={config.icon} className="text-white" />
      </div>
      {showText && (
        <span className={`font-bold ${config.text} tracking-tight`}>
          FitSense
        </span>
      )}
    </>
  );

  if (onClick) {
    return (
      <button 
        onClick={onClick}
        className={`flex items-center gap-2 hover:opacity-80 transition-opacity ${className}`}
      >
        {content}
      </button>
    );
  }

  return (
    <div className={`flex items-center gap-2 ${className}`}>
      {content}
    </div>
  );
}
